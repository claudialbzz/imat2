#!/bin/bash

# Nombre del archivo de datos y URL
DATA_FILE="ml-1m.zip"
DATA_URL="http://files.grouplens.org/datasets/movielens/ml-1m.zip"
EXTRACTED_DIR="ml-1m"
RATINGS_FILE="${EXTRACTED_DIR}/ratings.dat"
