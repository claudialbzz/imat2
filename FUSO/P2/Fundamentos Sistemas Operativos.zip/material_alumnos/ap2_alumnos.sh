#!/bin/bash
# Variables
DOWNLOAD_PATH="https://archive.ics.uci.edu/ml/machine-learning-databases/wine/wine.data"
HEADER="class,alcohol,malic_acid,ash,alcalinity_of_ash,magnesium,total_phenols,flavanoids,nonflavanoid_phenols,proanthocyanins,color_intensity,hue,od280/od315_of_diluted_wines,proline"
DATA_FILE="wine.data"
CSV_FILE="wine_headers.csv"
#[...]
